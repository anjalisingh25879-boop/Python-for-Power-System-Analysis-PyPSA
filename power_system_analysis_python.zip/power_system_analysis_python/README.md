# Power System Analysis Using Python

A beginner-friendly, menu-driven Python project for performing common power-system calculations. It is intended for educational use and demonstrates how programming can support electrical engineering analysis.

## Features
- Three-phase apparent, real, and reactive power
- Approximate three-phase transmission-line voltage drop
- Transmission efficiency from receiving-end power and line losses
- Capacitor kVAr estimate for power-factor correction

## Requirements
- Python 3.8 or later
- No third-party packages required

## How to run
1. Install Python from https://www.python.org/downloads/ if it is not already installed.
2. Download or clone this repository.
3. Open a terminal in the project folder.
4. Run:

   ```bash
   python main.py
   ```

5. Choose an option from the menu and enter the requested values.

## Formulas used

For a balanced three-phase system:
- Apparent power: `S = √3 × V_L × I_L`
- Real power: `P = √3 × V_L × I_L × cos(φ)`
- Reactive power: `Q = √3 × V_L × I_L × sin(φ)`

Approximate voltage drop for a short three-phase line with lagging power factor:
- `ΔV ≈ √3 × I × L × (R cos(φ) + X sin(φ))`

Transmission efficiency:
- `η = P_out / (P_out + losses) × 100`

Power-factor correction:
- `Q_c = P [tan(cos⁻¹(PF_initial)) − tan(cos⁻¹(PF_target))]`

## Example
For a 400 V, 10 A, three-phase load at 0.8 power factor:
- Apparent power = 6.928 kVA
- Real power = 5.543 kW
- Reactive power = 4.157 kVAr

## Project structure
```text
power_system_analysis_python/
├── main.py
├── README.md
└── requirements.txt
```

## Limitations
This is an educational calculator, not a protection, planning, or grid-operation tool. Voltage-drop calculation uses a simplified short-line approximation and assumes lagging power factor. Verify engineering results independently before using them in real systems.

## Author
Add your name, college, and project date here before publishing.
