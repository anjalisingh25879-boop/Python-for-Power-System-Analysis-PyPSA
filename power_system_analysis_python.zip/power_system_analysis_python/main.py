"""
Power System Analysis Using Python
A simple menu-driven tool for three-phase power, voltage drop,
transmission efficiency, and basic power-factor correction.
"""
import math

def positive(prompt):
    while True:
        try:
            value = float(input(prompt))
            if value > 0:
                return value
            print("Enter a value greater than zero.")
        except ValueError:
            print("Enter a valid number.")

def three_phase():
    voltage = positive("Line voltage (V): ")
    current = positive("Line current (A): ")
    pf = float(input("Power factor (0 to 1): "))
    if not 0 <= pf <= 1:
        print("Power factor must be between 0 and 1.")
        return
    apparent = math.sqrt(3) * voltage * current
    real = apparent * pf
    reactive = apparent * math.sqrt(1 - pf**2)
    print(f"Apparent power: {apparent/1000:.3f} kVA")
    print(f"Real power:      {real/1000:.3f} kW")
    print(f"Reactive power:  {reactive/1000:.3f} kVAr")

def voltage_drop():
    current = positive("Line current (A): ")
    resistance = positive("Resistance per phase (ohm): ")
    reactance = positive("Reactance per phase (ohm): ")
    length = positive("Line length (km): ")
    pf = float(input("Power factor (0 to 1): "))
    if not 0 <= pf <= 1:
        print("Power factor must be between 0 and 1.")
        return
    sin_phi = math.sqrt(1-pf**2)
    # Approximate 3-phase line-to-line voltage drop, lagging power factor
    drop = math.sqrt(3)*current*length*(resistance*pf + reactance*sin_phi)
    print(f"Approximate line voltage drop: {drop:.2f} V")
    print("Note: This uses the short-line approximation and assumes lagging PF.")

def efficiency():
    output_kw = positive("Receiving-end real power (kW): ")
    losses_kw = float(input("Total line losses (kW): "))
    if losses_kw < 0:
        print("Losses cannot be negative.")
        return
    input_kw = output_kw + losses_kw
    print(f"Sending-end power: {input_kw:.3f} kW")
    print(f"Transmission efficiency: {100*output_kw/input_kw:.2f}%")

def power_factor_correction():
    p_kw = positive("Load real power (kW): ")
    old_pf = float(input("Initial power factor (0 to 1): "))
    new_pf = float(input("Target power factor (0 to 1): "))
    if not (0 < old_pf <= 1 and 0 < new_pf <= 1):
        print("Power factors must be greater than 0 and at most 1.")
        return
    q1 = p_kw*math.tan(math.acos(old_pf))
    q2 = p_kw*math.tan(math.acos(new_pf))
    print(f"Required capacitor rating: {max(0, q1-q2):.3f} kVAr")

def main():
    options = {
        "1": ("Three-phase power calculation", three_phase),
        "2": ("Transmission line voltage drop", voltage_drop),
        "3": ("Transmission efficiency", efficiency),
        "4": ("Power-factor correction", power_factor_correction),
    }
    while True:
        print("\n=== POWER SYSTEM ANALYSIS ===")
        for key, (label, _) in options.items():
            print(f"{key}. {label}")
        print("0. Exit")
        choice = input("Choose an option: ").strip()
        if choice == "0":
            print("Thank you for using the project.")
            break
        if choice in options:
            print(f"\n--- {options[choice][0]} ---")
            options[choice][1]()
        else:
            print("Invalid choice. Select 0–4.")

if __name__ == "__main__":
    main()
